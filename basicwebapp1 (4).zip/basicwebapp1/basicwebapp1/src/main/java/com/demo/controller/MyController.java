package com.demo.controller;

import java.util.ArrayList;
import com.demo.main.*;
import java.util.List;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.demo.model.UserInfo;

@Controller
public class MyController {
	
	private MyControllerDAO MyControllerDAO;
	
	@ModelAttribute
	public void addAccountToModel(Model model) {
		System.out.println("Making sure account object is on model");
			if(!model.containsAttribute("userinfo")){
				UserInfo a = new UserInfo();
				model.addAttribute("userinfo", a);
			}
	}	
	@RequestMapping(value="/Welcome")
	public String getWelcome(@Valid @ModelAttribute ("userinfo") UserInfo userinfo,BindingResult result) 
	{
		if(result.hasErrors())
			{
				System.out.println("Form has Errors");
				return "Welcome";
			}
			System.out.println("Form Validated"); 
			System.out.println(userinfo.getUsername()+" "+userinfo.getPassword());
		//System.out.println(userinfo.getPassword());
		return "Welcome";
	}
	
/*	@RequestMapping(value="/Welcome")
	public String createAccount(@Valid @ModelAttribute ("userinfo") UserInfo userinfo ,BindingResult result){		
			if(result.hasErrors())
			{
				System.out.println("Form has Errors");
				return "Welcome";
			}
			System.out.println("Form Validated");
			System.out.println(userinfo.getUsername()+" "+userinfo.getPassword());
			return "Welcome";
	}*/
	
	@RequestMapping(value="/register")
	public String getRegister(@ModelAttribute ("userinfo") UserInfo userinfo) 
	{
//		System.out.println(userinfo.getUsername());
//		System.out.println(userinfo.getPassword());
		return "register";
	}
	
	@RequestMapping(value="/validate",method=RequestMethod.GET)
	public String validateinfo(@ModelAttribute ("userinfo") UserInfo userinfo,Model model)
	{
		
	/*	{
			if(result.hasErrors())
			{
			System.out.println("Form has Errors");
			return "Welcome";
			}
			
		System.out.println("Form Validated");
		System.out.println(userinfo.getUsername()+" "+userinfo.getPassword());
		//System.out.println(userinfo.getPassword());
		return "validate";
		}*/
	
		//System.out.println("Form Validated");
		//System.out.println("inside validation");
		//System.out.println(userinfo.getUsername());
		//System.out.println(userinfo.getPassword());
		String uname=userinfo.getUsername();
		String pwd=userinfo.getPassword();
		System.out.println(uname);
		System.out.println(pwd);
		model.addAttribute("uname", uname);
		String finalpage="";
//		List<UserInfo> ui=new ArrayList<>();
//		ui= MyControllerDAO.getData();
//		System.out.println(ui);
		
//		myApp.main();
		//System.out.println("Calling main fromController");
		myApp m=new myApp();
		String res=myApp.main(new String[] {uname,pwd});
	//	System.out.println("received result from main");
		
		if (res.equals("validuser")) {
			model.addAttribute("uname", uname);
			finalpage="/validuser";
		}
			else
	
	//	if (res.equals("invalidpassword")) 
		{	
				//System.out.println();
			//finalpage= "/invalidpassword";
			finalpage="Entered username or password invalid";
		}
		
		return finalpage;
	}
	
	@RequestMapping(value="/add")
	public String addinfo(@ModelAttribute ("userinfo") UserInfo userinfo,Model model)
	{
		System.out.println("inside validation");
		System.out.println(userinfo.getUsername());
		System.out.println(userinfo.getPassword());
		String uname=userinfo.getUsername();
		String pwd=userinfo.getPassword();
	//	System.out.println(uname);
	//	System.out.println(pwd);
		model.addAttribute("uname", uname);
		String finalpage="";
//		List<UserInfo> ui=new ArrayList<>();
//		ui= MyControllerDAO.getData();
//		System.out.println(ui);
		
//		myApp.main();
		//System.out.println("Calling main fromController");
		addUser m=new addUser();
		String res1=addUser.main(new String[] {uname,pwd});
	//	System.out.println("received result from main");
		
		if (res1.equals("success")) {
			finalpage="/Welcome";
		}
			else
	
	//	if (res.equals("invalidpassword")) 
		{	
				//System.out.println();
			//finalpage= "/invalidpassword";
			finalpage="Entered username or password invalid";
		}
		
		return finalpage;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
//	@GetMapping("/hello")
//	public String sayhello()
//	{
//		System.out.println("Inside Hello");
//		return "hello";
//	}

}
