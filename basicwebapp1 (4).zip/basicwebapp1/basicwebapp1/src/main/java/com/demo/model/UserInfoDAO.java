package com.demo.model;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Component;

@Component("userInfoDAO")
public class UserInfoDAO {
	
	private NamedParameterJdbcTemplate myJdbcTemplate;
	String res="";
	public NamedParameterJdbcTemplate getMyJdbcTemplate() {
		return myJdbcTemplate;
	}
	
	@Autowired
	public void setMyJdbcTemplate(DataSource ds) {
		this.myJdbcTemplate =new NamedParameterJdbcTemplate(ds);
	}
	
/*	public String validateuser(final String enteredname,final String pwd)
	{
		
		MapSqlParameterSource params = new MapSqlParameterSource();
		params.addValue("name", enteredname);
		params.addValue("password", pwd);
		
		
		System.out.println(enteredname+" "+pwd);
		 myJdbcTemplate.query("select * from login where name=:enteredname and password=:pwd ",params,
				new RowMapper<UserInfo>() {
			 
					public UserInfo mapRow(ResultSet rs, int rowNum) throws SQLException {
						if(rowNum==0)
						{
							if(rs.getString("name").equals(enteredname))
							{
								if(rs.getString("password").equals(pwd))
								{
									System.out.println("Welcome "+enteredname);
									res=res+"validuser";
									
								}
								else
								{
									System.out.println("Invalid password for user "+enteredname);
									res=res+"invalidpassword";
								}
							}
							else
							{
								System.out.println("User with name "+enteredname+" doesnt exist");
								res=res+"invaliduser";
							}
							
						}
						else {
							System.out.println("Invalid User");
							res=res+"invaliduser";
						}
						return null;
						
						
//						UserInfo ui = new UserInfo();
//						ui.setUsername(rs.getString("name"));
//						ui.setPassword(rs.getString("Password"));
//						System.out.println(rs.getString("name"));
//						System.out.println(rs.getString("password"));
						
					}
				}
			);
		 System.out.println("Returning result from userinfoDAO to myApp");
		return res; */
		
		
//		int rowsAffected=myJdbcTemplate.query("select * from UserData where name=:name", (ResultSetExtractor<T>) params);
//		if(rowsAffected==1)
//		{
//			System.out.println("Insert Successful");
//			res=true;
//		}else {
//			System.out.println("Insert Unsuccessfull");
//		}
//		return res;
		
//		myJdbcTemplate.query("select * from UserData where", rse)
//		
//		return false;
		
	
	 public String addUser(final String enteredname,final String pwd)
		{ 
	//	Boolean res = false; 
		 String res1="";
		MapSqlParameterSource params = new MapSqlParameterSource(); 
		params.addValue("name",enteredname); 
		params.addValue("password",pwd); 
		
		int numOfRowsAffected=myJdbcTemplate.update("insert into login (name,password)values(:name,:password)",params);
		
		if(numOfRowsAffected == 1){ 
			System.out.println("successfully");
			res1 = "success"; 
		}
		else{ 
			System.out.println("There was a problem adding to table foodgroups") ;
			res1="fail";
		}
		return res1; 
		}
	 
		
		public String validateuser(final String enteredname,final String pwd)
		{
			
			MapSqlParameterSource params = new MapSqlParameterSource();
			params.addValue("name", enteredname);
			params.addValue("password", pwd);
			
			
			System.out.println(enteredname+" "+pwd);
			 myJdbcTemplate.query("select * from login where name=:name and password=:password ",params,
					new RowMapper<UserInfo>() {
				 
						public UserInfo mapRow(ResultSet rs, int rowNum) throws SQLException {
							if(rowNum==0)
							{
								if(rs.getString("name").equals(enteredname) && rs.getString("password").equals(pwd))
								{
										System.out.println("Welcome "+enteredname);
										res=res+"validuser";
										
								}
								else
								{
										System.out.println("Invalid password or username ");
										res=res+"invalidpassword";
								}
								
							}
								//else
								//{
									//System.out.println("User with name "+enteredname+" doesnt exist");
									//res=res+"invaliduser";
								//}
								
							//}
							//else {
								//System.out.println("Invalid User");
								//res=res+"invaliduser";
							//}
							return null;
						}
			 }
			);
		// System.out.println("Returning result from userinfoDAO to myApp");
		return res;
	}

}
