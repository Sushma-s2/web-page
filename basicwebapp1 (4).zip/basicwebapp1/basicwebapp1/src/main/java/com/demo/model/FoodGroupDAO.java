package com.demo.model;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSourceUtils;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;


@Component("foodGroupDAO")
public class FoodGroupDAO {

//	private JdbcTemplate myJdbcTemplate;
	
	private NamedParameterJdbcTemplate myJdbcTemplate;  //->Named Parameter template to use named params in query
//	public List<FoodGroup> getFoodGroups(){
		
//		
//		//To use and map Named Parameters in our Query
//		MapSqlParameterSource myMap = new MapSqlParameterSource();
//		myMap.addValue("groupName", "VEG");
//		return myJdbcTemplate.query("select * from foodgroups where name=:groupName",myMap, 			
//		new RowMapper<FoodGroup>() {
//			public FoodGroup mapRow(ResultSet rs, int rowNum) throws SQLException {
//				FoodGroup fg = new FoodGroup();
//				fg.setId(rs.getInt("id"));
//				fg.setName(rs.getString("name"));
//				fg.setDescription(rs.getString("description"));
//				return fg;
//			}
//		}
//	);
//	}
		
		
		//RETRIEVING SINGLE RECORDS AS OBJECTS
		//To use and map Named Parameters in our Query
//		public FoodGroup getFoodGroup(int id)
//		{
//			MapSqlParameterSource myMap = new MapSqlParameterSource();
//			myMap.addValue("id", id);
//			
//			return myJdbcTemplate.queryForObject("select * from foodgroups where id=:id",myMap, 
//					
//					new RowMapper<FoodGroup>() {
//						public FoodGroup mapRow(ResultSet rs, int rowNum) throws SQLException {
//							FoodGroup fg = new FoodGroup();
//							fg.setId(rs.getInt("id"));
//							fg.setName(rs.getString("name"));
//							fg.setDescription(rs.getString("description"));
//							return fg;
//						}
//					}
//				);
//			
//		}
	
	//INSERTING DATA INTO DATABASE
	public boolean addFoodGroup(String name,String description)
	{
		MapSqlParameterSource params = new MapSqlParameterSource();
		//params.addValue("id", id);
		params.addValue("name", name);
		params.addValue("description", description);
		boolean res=false;
		
		int rowsAffected=myJdbcTemplate.update("insert into foodgroups(name,description) values(:name,:description)", params);
		if(rowsAffected==1)
		{
			System.out.println("Insert Successful");
			res=true;
		}else {
			System.out.println("Insert Unsuccessfull");
		}
		return res;
		
	}
	
	
	
	//USING BEAN PROPERTIES AS SQL PARAMETERS
//	public boolean create(FoodGroup fg)
//	{
//		BeanPropertySqlParameterSource params=new BeanPropertySqlParameterSource(fg);
//		boolean res=false;
//		int rowsAffected=myJdbcTemplate.update("insert into foodgroups(name,description) values(:name,:description)", params);
//		if(rowsAffected==1)
//		{
//			System.out.println("Insert Successful");
//			res=true;
//		}else {
//			System.out.println("Insert Unsuccessfull");
//		}
//		return res;
//	
//		
//	}
		
	
	//UPDATING DATA IN DATABASE
//	public boolean update(FoodGroup fg)
//	{
//		BeanPropertySqlParameterSource params=new BeanPropertySqlParameterSource(fg);
//		boolean res=false;
//		int rowsAffected=myJdbcTemplate.update("update foodgroups set name=:name , description=:description where id=:id", params);
//		if(rowsAffected==1)
//		{
//			System.out.println("Update Successful");
//			res=true;
//		}else {
//			System.out.println("Update Unsuccessfull");
//		}
//		return res;	
//	}
	
	
	//DELETING DATA IN DATABASE
//	public boolean delete(int id)
//	{
//		MapSqlParameterSource params = new MapSqlParameterSource();
//		params.addValue("id", id);
//		boolean res=false;
//		int rowsAffected=myJdbcTemplate.update("delete from foodgroupS where id=:id", params);
//		if(rowsAffected==1)
//		{
//			System.out.println("Delete Successful");
//			res=true;
//		}else {
//			System.out.println("Delete Unsuccessfull");
//		}
//		return res;	
//	}
	
	
	//PERFORMING BATCH UPDATES
//	public int[] createFoodGroups(ArrayList<FoodGroup> groups) {
//		
//		SqlParameterSource[] batchArgs=SqlParameterSourceUtils.createBatch(groups.toArray());
//		int[] numOfRowsAffected=myJdbcTemplate.batchUpdate("insert into foodgroups (name,description) values(:name,:description)", batchArgs);
//		
//		return numOfRowsAffected;
//	}
//	
	
	
	//USING DB TRANSACTIONS IN SPRING
//	@Transactional("myTransactionManager")
//		public int[] createFoodGroups(ArrayList<FoodGroup> groups) {
//		
//		SqlParameterSource[] batchArgs=SqlParameterSourceUtils.createBatch(groups.toArray());
//		int[] numOfRowsAffected=myJdbcTemplate.batchUpdate("insert into foodgroups (name,description) values(:name,:description)", batchArgs);
//		
//		return numOfRowsAffected;
//	}
	
	
	
	
//}
	
//	public JdbcTemplate getMyJdbcTemplate() {
//		return myJdbcTemplate;
//	}
//
//	@Autowired
//	public void setMyJdbcTemplate(DataSource ds) {
//		this.myJdbcTemplate =new JdbcTemplate(ds);
//	}
	
	
	//
	
	// USING SIMPLE JDBC INSERT
//	private SimpleJdbcInsert insertFoodGroup;
//	public int create_si(FoodGroup fg) {
//		SqlParameterSource params = new BeanPropertySqlParameterSource(fg);

//		------------------1st method---------------------		
//		int numOfRowsAffected = insertFoodGroup.execute(params);
//		return numOfRowsAffected;
		
		
//		------------------2nd method---------------------		
//		Number insertID=insertFoodGroup.executeAndReturnKey(params);
//		System.out.println("Record inserted ID : "+ insertID);
//		return insertID.intValue();
		
	
	
	public NamedParameterJdbcTemplate getMyJdbcTemplate() {
		return myJdbcTemplate;
	}

//	@Autowired
//	public void setMyJdbcTemplate(DataSource ds) {
//		this.myJdbcTemplate =new NamedParameterJdbcTemplate(ds);
//	}
	
	
	//USING SIMPLE JDBC INSERT
	@Autowired
	public void setMyJdbcTemplate(DataSource ds) {
		this.myJdbcTemplate =new NamedParameterJdbcTemplate(ds);
		
//		------------------1st method---------------------		
//		this.insertFoodGroup=new SimpleJdbcInsert(ds).withTableName("foodgroups");
		
//		
////		------------------2nd method---------------------		
//		this.insertFoodGroup=new SimpleJdbcInsert(ds).withTableName("foodgroups").usingGeneratedKeyColumns("id");
//
//	}
	
}
	}
