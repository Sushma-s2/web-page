package com.demo.controller;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Component;

import com.demo.model.UserInfo;

@Component("MyControllerDAO")
public class MyControllerDAO {

	private NamedParameterJdbcTemplate myTemplate;

	public void setMyTemplate(DataSource ds) {
		this.myTemplate = new NamedParameterJdbcTemplate(ds);
	}

	public List<UserInfo> getData() {
		MapSqlParameterSource myMap = new MapSqlParameterSource();
		myMap.addValue("Username","uname");
//		myMap.addValue("Password","pwd");
	    return myTemplate.query("select * from UserData where name=:name",myMap, 
			
			new RowMapper<UserInfo>() {
				public UserInfo mapRow(ResultSet rs, int rowNum) throws SQLException {
					UserInfo ui = new UserInfo();
					ui.setUsername(rs.getString("name"));
					ui.setPassword(rs.getString("Password"));
					System.out.println(rs.getString("name"));
					System.out.println(rs.getString("password"));
					return ui;
				}
			}
		);
	}
//	public boolean compare(String uname,String pwd)
//	{
//		MapSqlParameterSource myMap = new MapSqlParameterSource();
//		myMap.addValue("Username","uname");
//		myMap.addValue("Password","pwd");
//		
//		 myTemplate.query("select * from UserData where name=:uname",myMap, 
//				
//				new RowMapper<UserInfo>() {
//					public UserInfo mapRow(ResultSet rs, int rowNum) throws SQLException {
//						System.out.println(rowNum);
//						if(rowNum==1)
//						{
//							System.out.println("Valid User Exists");
//							if(rs.getString("Password").equals(pwd))
//							{
//								System.out.println("Welcome "+uname);
//							}
//							else
//							{
//								System.out.println("Invalid Passsword");
//							}
//						}
//						else if(rowNum==0)
//						{
//							System.out.println("User Does not Exist");
//						}
//						else {
//							
//						}
//						
//					
//			
//
//				
//						
//					}
//		});
//		return false;
	
	

}

