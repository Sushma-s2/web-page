package com.demo.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

import com.demo.model.UserInfoDAO;

public class addUser {

	public static String main(String[] args) {
		// TODO Auto-g
		ApplicationContext appContext =new FileSystemXmlApplicationContext("C:\\Users\\ss682\\OneDrive - DXC Production\\Desktop\\SpringProjects\\basicwebapp1\\basicwebapp1\\src\\main\\webapp\\WEB-INF\\appContext.xml");
		
		UserInfoDAO myUIDAO1 = appContext.getBean("userInfoDAO",UserInfoDAO.class);
		
		String user=args[0];
		String pwd=args[1];
		
		String res1=myUIDAO1.addUser(user, pwd);
		return res1;

	}

}
