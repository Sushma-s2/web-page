package com.demo.main;
//import java.util.List;
//
//import org.springframework.context.ApplicationContext;
//import org.springframework.context.support.FileSystemXmlApplicationContext;
//
//import com.demo.controller.MyControllerDAO;
//import com.demo.model.UserInfo;
//
//public class myApp {
//public static void main(String[] args) {
//	ApplicationContext appContext =new FileSystemXmlApplicationContext("C:\\Users\\vs295\\Documents\\workspace-spring-tool-suite-4-4.8.0.RELEASE\\basicwebapp1\\src\\main\\webapp\\WEB-INF\\appContext.xml");
//	MyControllerDAO MyControllerDAO =appContext.getBean("MyControllerDAO",MyControllerDAO.class);
//	
//	List<UserInfo> myUserInfo=MyControllerDAO.getData();
//	for(UserInfo ui:myUserInfo) {
//		System.out.println(ui.getUsername());
//		System.out.println(ui.getPassword());
//	}
//	
//}
//}



import java.util.ArrayList;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;
import org.springframework.dao.DataAccessException;

import com.demo.model.FoodGroup;
import com.demo.model.FoodGroupDAO;
import com.demo.model.UserInfoDAO;

public class myApp {
	
	public static String main(String[] args) {
		ApplicationContext appContext =new FileSystemXmlApplicationContext("C:\\Users\\ss682\\OneDrive - DXC Production\\Desktop\\SpringProjects\\basicwebapp1\\basicwebapp1\\src\\main\\webapp\\WEB-INF\\appContext.xml");
		FoodGroupDAO myFoodGroupDAO =appContext.getBean("foodGroupDAO",FoodGroupDAO.class);
		UserInfoDAO myUIDAO = appContext.getBean("userInfoDAO",UserInfoDAO.class);
		UserInfoDAO myUIDAO1 = appContext.getBean("userInfoDAO",UserInfoDAO.class);
		
		String user=args[0];
		String pwd=args[1];
	//	System.out.println("calling Validate user method from myApp to UIDAO");
		
		String res=myUIDAO.validateuser(user,pwd);
	//	System.out.println("Received result From UIDAO to MyApp");
		return res;
		
	//	String res1=myUIDAO1.addUser(user, pwd);
	//	return res1;
		
		
		
//		List<FoodGroup> myFoodGroupList =myFoodGroupDAO.getFoodGroups();
//		for(FoodGroup fg:myFoodGroupList) {
//			System.out.println(fg.TalkAboutYourself());
//		}
		
		
		//RETRIEVING SINGLE RECORDS AS OBJECTS
//		FoodGroup meat=myFoodGroupDAO.getFoodGroup(4);
//		System.out.println(meat.TalkAboutYourself());

		
		
		//INSERTING DATA INTO DATABASE
//		myFoodGroupDAO.addFoodGroup("NotFoodGrp1", "Not Really A Food Group1");
		
		
		//USING BEAN PROPERTIES AS SQL PARAMETERS
//		FoodGroup myfg=new FoodGroup("RandomFG","Just a random FG");
//		myFoodGroupDAO.create(myfg);
		
		
		//UPDATING DATA IN DATABASE
//		FoodGroup myfg=new FoodGroup(7,"UpdatedFG","Just an updated FG");
//		myFoodGroupDAO.update(myfg);
		
		//DELETING DATA IN DATABASE
//		myFoodGroupDAO.delete(13);
		
		
//		//HANDLING A DATABASE EXCEPTION
//		try {
//		myFoodGroupDAO.delete(7);
//		}catch(DataAccessException e)
//		{
//			System.out.println(e.getMessage());
//			System.out.println(e.getClass());
//		}
		
		
//		PERFORMING BATCH UPDATES
//		FoodGroup a=new FoodGroup("A","Iam A");
//		FoodGroup b=new FoodGroup("B","Iam B");
//		FoodGroup c=new FoodGroup("C","Iam C");
//		
//		ArrayList<FoodGroup> mylist=new ArrayList<FoodGroup>();
//		mylist.add(a);
//		mylist.add(b);
//		mylist.add(c);
//		
//		int[] affectedRowsArray=myFoodGroupDAO.createFoodGroups(mylist);
//		for(int aR:affectedRowsArray)
//		{
//			System.out.println("Updated Rows "+aR);
//		}
		
		
		// USING DB TRANSACTIONS IN SPRING
//		FoodGroup d=new FoodGroup("D","Iam D");
//		FoodGroup e=new FoodGroup("E","Iam E");
//		FoodGroup d2=new FoodGroup("D","Iam F");
//		try {
//		ArrayList<FoodGroup> mylist=new ArrayList<FoodGroup>();
//		mylist.add(d);
//		mylist.add(e);
//		mylist.add(d);
//		}
//		catch(Exception e)
//		{
//			System.out.println(e.getMessage());
//			System.out.println(e.getClass());
//		}
//		int[] affectedRowsArray=myFoodGroupDAO.createFoodGroups(mylist);
//		for(int aR:affectedRowsArray)
//		{
//			System.out.println("Updated Rows "+aR);
//		}

		
		//USING SIMPLE JDBC INSERT
//		FoodGroup a=new FoodGroup("G","Iam G");
//		myFoodGroupDAO.create_si(a);

		
		
		
	}

}

